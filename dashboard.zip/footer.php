<footer class="footer" style="padding-bottom: 0px;">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> Powered by <a href="http://www.thinkinnovation.tech">Think Innovation</a>, Tel: +256 752943699, 0752596322
                </p>
            </div>
        </footer>
